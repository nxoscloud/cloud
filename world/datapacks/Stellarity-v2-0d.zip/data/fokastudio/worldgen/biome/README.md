# 'fokastudio' biomes

These are kept for compatibility purposes.

When updating the pack from older versions, old biomes are still saved in `level.dat`. The game still checks for their files instead of overwriting them, and if they are not present then well...
